/* --- BANCO DE PREGUNTAS --- */
// Importante: El nombre debe coincidir con el que busca mostrarTrivia
const bancoDePreguntas = {
    "2016": [
        { p: "¿Qué día nos hicimos novios?", o: ["15 de Nov", "21 de Nov", "22 de Nov"], c: 1 },
        { p: "¿Quién dio el primer paso?", o: ["Bárbara", "Yo", "Fue mutuo"], c: 1 },
        { p: "¿Nuestra primera salida fue a?", o: ["Un parque", "Cine", "Mall"], c: 0 },
        { p: "¿Qué color de ropa usaba ella ese día?", o: ["Negro", "Blanco", "Rojo"], c: 0 },
        { p: "¿Qué canción nos dedicamos primero?", o: ["Canción A", "Canción B", "Canción C"], c: 1 },
        { p: "¿Cuál fue nuestro primer apodo?", o: ["Amor", "Gordi", "Cielo"], c: 2 },
        { p: "¿Cómo se llama el lugar donde nos conocimos?", o: ["Lugar X", "Lugar Y", "Lugar Z"], c: 0 },
        { p: "¿Qué mes era cuando empezamos a hablar?", o: ["Octubre", "Noviembre", "Septiembre"], c: 0 },
        { p: "¿Quién es más celoso?", o: ["Bárbara", "Yo", "Ninguno"], c: 1 },
        { p: "¿Nuestra primera foto fue en?", o: ["Tu casa", "La calle", "Un restaurante"], c: 2 }
    ],
    "2017": [
        { p: "¿A dónde fuimos en nuestro primer viaje?", o: ["Playa", "Montaña", "Campo"], c: 0 },
        // Puedes seguir completando los demás años con 10 preguntas cada uno
    ]
};

/* --- FUNCIÓN PRINCIPAL DE TRIVIA --- */
function mostrarTrivia(ref) {
    const contenedor = document.getElementById('contenedor-trivia');
    const preguntasAño = bancoDePreguntas[ref.año] || [];
    
    document.body.style.overflow = 'hidden';

    let preguntaActual = 0;
    let aciertos = 0;

    // Mostramos el cuadro sin ocultar el universo (para mantener el fondo del planeta)
    contenedor.style.display = 'block';
    
    function desbloquearScroll() {
    document.body.style.overflow = 'auto';
    }

    function renderizarPregunta() {
        if (preguntaActual < preguntasAño.length) {
            const data = preguntasAño[preguntaActual];
            document.getElementById('trivia-titulo').innerText = `Año ${ref.año} (${preguntaActual + 1}/10)`;
            document.getElementById('trivia-pregunta').innerText = data.p;
            
            const opcionesDiv = document.getElementById('trivia-opciones');
            opcionesDiv.innerHTML = ''; 

            data.o.forEach((opcion, index) => {
                const btn = document.createElement('button');
                btn.className = 'boton-opcion';
                btn.innerText = opcion;
                btn.onclick = () => {
                    if (index === data.c) aciertos++;
                    preguntaActual++;
                    renderizarPregunta();
                };
                opcionesDiv.appendChild(btn);
            });
        } else {
            finalizarTrivia();
        }
    }

    function finalizarTrivia() {
        const opcionesDiv = document.getElementById('trivia-opciones');
        if (aciertos >= 7) {
            document.getElementById('trivia-pregunta').innerText = `¡Increíble! Lograste ${aciertos}/10 correctas.`;
            opcionesDiv.innerHTML = `<button class="boton-opcion" onclick="cerrarTriviaExito(${ref.año})">Desbloquear Recuerdo</button>`;
            
            // Si tienes la función de fuegos artificiales, se activa aquí
            if (typeof crearCorazonExplosivo === 'function') {
                crearCorazonExplosivo('cadetblue');
            }
        } else {
            document.getElementById('trivia-pregunta').innerText = `Casi... sacaste ${aciertos}/10. ¡Inténtalo de nuevo!`;
            opcionesDiv.innerHTML = `<button class="boton-opcion" onclick="reintentarTrivia()">Reintentar</button>`;
        }
    }

    renderizarPregunta();
}

/* --- FUNCIONES DE CIERRE Y CONTROL --- */
function cerrarTriviaExito(año) {
    document.getElementById('contenedor-trivia').style.display = 'none';

    desbloquearScroll();
    
    const univ = document.getElementById('universo');
    univ.style.transform = "scale(1)";
    univ.style.opacity = "1";

    // Buscamos el planeta en la lista global para marcarlo como completado
    if (typeof planetasRefs !== 'undefined') {
        const pRef = planetasRefs.find(p => p.año == año);
        if (pRef) {
            pRef.completado = true;
            pRef.el.style.boxShadow = "0 0 30px white, inset 0 0 10px white"; // Brillo de éxito
            pRef.activo = true; // Que siga orbitando pero ya brilla
        }
    }
}

function reintentarTrivia() {
    document.getElementById('contenedor-trivia').style.display = 'none';
    
    // IMPORTANTE: Liberar el scroll del fondo
    document.body.style.overflow = 'auto';

    const univ = document.getElementById('universo');
    univ.style.transform = "scale(1)";
    univ.style.opacity = "1";
    
    // Reactivar movimiento
    if (typeof planetasRefs !== 'undefined') {
        planetasRefs.forEach(p => p.activo = true);
    }
}